package com.example.pierangelo.listviewjson;

import org.json.JSONArray;

/**
 * Created by pierangelo on 30/05/15.
 */
public class getResponseText extends JSONArray {
    public getResponseText(Object p0) {
    }


}
